import upperFirst from 'lodash/upperFirst'

export default function (string) {
  return upperFirst(string)
}
