<template>
  <CustomError404 />
</template>

<script>
import Guest from '@/layouts/Guest'

export default {
  name: 'Error404Page',

  layout: Guest,
}
</script>
