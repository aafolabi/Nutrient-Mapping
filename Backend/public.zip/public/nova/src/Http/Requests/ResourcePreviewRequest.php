<?php

namespace Laravel\Nova\Http\Requests;

class ResourcePreviewRequest extends ResourceDetailRequest
{
    //
}
