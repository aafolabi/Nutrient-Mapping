<?php

namespace Laravel\Nova\Contracts;

/**
 * @mixin \Laravel\Nova\Fields\Field
 */
interface ListableField extends BehavesAsPanel
{
    //
}
